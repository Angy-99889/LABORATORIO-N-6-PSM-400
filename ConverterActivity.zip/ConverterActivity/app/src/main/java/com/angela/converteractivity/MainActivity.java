package com.angela.converteractivity;


import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    Spinner spType, spFrom, spTo;
    EditText etValue;
    TextView tvResult;
    Button btnConvert;

    String[] types = {"Longitud","Peso","Temperatura"};
    String[] len = {"m","km","cm","mm"};
    String[] weight = {"kg","g","lb"};
    String[] temp = {"C","F","K"};

    @Override protected void onCreate(Bundle s){
        super.onCreate(s);
        setContentView(R.layout.activity_main);
        spType = findViewById(R.id.spType);
        spFrom = findViewById(R.id.spFrom);
        spTo = findViewById(R.id.spTo);
        etValue = findViewById(R.id.etValue);
        tvResult = findViewById(R.id.tvResult);
        btnConvert = findViewById(R.id.btnConvert);

        ArrayAdapter<String> adTypes = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, types);
        adTypes.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spType.setAdapter(adTypes);

        spType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id){
                String[] items = pos==0?len: pos==1?weight: temp;
                ArrayAdapter<String> ad = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_spinner_item, items);
                ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spFrom.setAdapter(ad); spTo.setAdapter(ad);
            }
            @Override public void onNothingSelected(AdapterView<?> p){}
        });

        btnConvert.setOnClickListener(view -> {
            String from = (String)spFrom.getSelectedItem();
            String to = (String)spTo.getSelectedItem();
            double v = 0;
            try{ v = Double.parseDouble(etValue.getText().toString()); } catch(Exception e){ tvResult.setText("Ingresa un número"); return; }
            double res = 0;
            switch((String)spType.getSelectedItem()){
                case "Longitud": res = convertLength(v, from, to); break;
                case "Peso": res = convertWeight(v, from, to); break;
                case "Temperatura": res = convertTemp(v, from, to); break;
            }
            tvResult.setText(String.format("%.6f %s", res, to));
        });
    }

    double convertLength(double val, String from, String to){
        double meters = val * (from.equals("km")?1000: from.equals("m")?1: from.equals("cm")?0.01:0.001);
        double toFactor = to.equals("km")?0.001: to.equals("m")?1: to.equals("cm")?100:1000;
        return meters * toFactor;
    }

    double convertWeight(double val, String from, String to){

        double kg = val * (from.equals("kg")?1: from.equals("g")?0.001: 0.45359237);
        double toFactor = to.equals("kg")?1: to.equals("g")?1000: 1/0.45359237;
        return kg * toFactor;
    }
    double convertTemp(double val, String from, String to){
        double c = 0;
        if(from.equals("C")) c = val;
        if(from.equals("F")) c = (val - 32) * 5/9;
        if(from.equals("K")) c = val - 273.15;
        if(to.equals("C")) return c;
        if(to.equals("F")) return c * 9/5 + 32;
        return c + 273.15;
    }
}
