package com.angela.calcactivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    TextView tv;
    double memory = 0.0;
    String current = "";
    double operand = 0;
    String operator = "";
    boolean isNew = true;

    @Override protected void onCreate(Bundle s){
        super.onCreate(s);
        setContentView(R.layout.activity_main);
        tv = findViewById(R.id.tvDisplay);

        int[] ids = {R.id.btn0,R.id.btn1,R.id.btn2,R.id.btn3,R.id.btn4,R.id.btn5,R.id.btn6,R.id.btn7,R.id.btn8,R.id.btn9,R.id.btnDot,
                R.id.btnAdd,R.id.btnSub,R.id.btnMul,R.id.btnDiv,R.id.btnEqual,R.id.btnClear,
                R.id.btnMC,R.id.btnMR,R.id.btnMplus,R.id.btnMminus,
                R.id.btnSqrt,R.id.btnPow,R.id.btnSin,R.id.btnCos};
        for(int id: ids) findViewById(id).setOnClickListener(this);
    }

    @Override public void onClick(View v){
        int id = v.getId();
        if(id==R.id.btnClear){ current=""; operator=""; operand=0; isNew=true; tv.setText("0"); return; }
        if(id==R.id.btnDot){ if(!current.contains(".")) current += current.isEmpty()?"0.":"."; tv.setText(current); return; }
        if(id>=R.id.btn0 && id<=R.id.btn9){
            String d = ((Button)v).getText().toString();
            current = isNew ? d : current + d;
            isNew = false;
            tv.setText(current);
            return;
        }
        if(id==R.id.btnAdd || id==R.id.btnSub || id==R.id.btnMul || id==R.id.btnDiv){
            commitPending();
            operator = ((Button)v).getText().toString();
            isNew = true;
            return;
        }
        if(id==R.id.btnEqual){
            commitPending();
            operator = "";
            isNew = true;
            tv.setText(format(operand));
            current = tv.getText().toString();
            return;
        }
        if(id==R.id.btnMC){ memory = 0; return; }
        if(id==R.id.btnMR){ tv.setText(format(memory)); current = format(memory); isNew = true; return; }
        if(id==R.id.btnMplus){ memory += parseCurrent(); return; }
        if(id==R.id.btnMminus){ memory -= parseCurrent(); return; }

        if(id==R.id.btnSqrt){ double v1 = Math.sqrt(parseCurrent()); tv.setText(format(v1)); current = format(v1); isNew=true; return; }
        if(id==R.id.btnPow){
            commitPending(); operator="^"; isNew=true; return;
        }
        if(id==R.id.btnSin){ double v2 = Math.sin(Math.toRadians(parseCurrent())); tv.setText(format(v2)); current = format(v2); isNew=true; return; }
        if(id==R.id.btnCos){ double v3 = Math.cos(Math.toRadians(parseCurrent())); tv.setText(format(v3)); current = format(v3); isNew=true; return; }
    }

    private double parseCurrent(){
        if(current==null || current.isEmpty()) return 0;
        try{ return Double.parseDouble(current); } catch(Exception e){ return 0; }
    }

    private void commitPending(){
        double cur = parseCurrent();
        if(operator==null || operator.isEmpty()){
            operand = cur;
        } else {
            switch(operator){
                case "+": operand = operand + cur; break;
                case "−":
                case "-": operand = operand - cur; break;
                case "×": operand = operand * cur; break;
                case "÷": operand = operand / (cur==0?1:cur); break;
                case "^": operand = Math.pow(operand, cur); break;
            }
        }
        tv.setText(format(operand));
        current = format(operand);
    }

    private String format(double v){
        if(Math.round(v) == v) return String.format(Locale.US,"%.0f", v);
        return String.format(Locale.US,"%.8f", v).replaceAll("0+$","").replaceAll("\\.$","");
    }
}