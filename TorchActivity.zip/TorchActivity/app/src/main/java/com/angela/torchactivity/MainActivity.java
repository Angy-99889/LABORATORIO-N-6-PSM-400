package com.angela.torchactivity;


import android.Manifest;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity extends AppCompatActivity {
    private CameraManager cameraManager;
    private String cameraId;
    ToggleButton toggle;
    Button btnBlink;
    EditText etInterval;
    Handler handler = new Handler();
    boolean blinking = false;
    Runnable blinkRunnable;

    final int REQ = 100;

    @Override protected void onCreate(Bundle s){
        super.onCreate(s);
        setContentView(R.layout.activity_main);
        toggle = findViewById(R.id.toggleTorch);
        btnBlink = findViewById(R.id.btnStartBlink);
        etInterval = findViewById(R.id.etInterval);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQ);
        }

        cameraManager = (CameraManager)getSystemService(CAMERA_SERVICE);
        try{
            for(String id : cameraManager.getCameraIdList()){

                if(cameraManager.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE)){
                    cameraId = id; break;
                }
            }
        } catch (CameraAccessException e){ e.printStackTrace(); }

        toggle.setOnCheckedChangeListener((buttonView, isChecked) -> {
            setTorch(isChecked);
        });

        btnBlink.setOnClickListener(v -> {
            if(blinking){
                stopBlink();
            } else {
                String sInterval = etInterval.getText().toString();
                int interval = 500;
                try{ interval = Integer.parseInt(sInterval); }catch(Exception e){}
                startBlink(interval);
            }
        });
    }

    void setTorch(boolean on){
        if(cameraId==null) return;
        try{ cameraManager.setTorchMode(cameraId, on); } catch(CameraAccessException e){ e.printStackTrace(); }
    }

    void startBlink(int intervalMs){
        blinking = true;
        btnBlink.setText("Detener Parpadeo");
        blinkRunnable = new Runnable(){
            boolean state = false;
            @Override public void run(){
                state = !state;
                setTorch(state);
                toggle.setChecked(state);
                handler.postDelayed(this, intervalMs);
            }
        };
        handler.post(blinkRunnable);
    }

    void stopBlink(){
        blinking = false;
        btnBlink.setText("Iniciar Parpadeo");
        if(blinkRunnable!=null) handler.removeCallbacks(blinkRunnable);
        setTorch(false);
        toggle.setChecked(false);
    }

    @Override protected void onPause(){
        super.onPause();
        stopBlink();
    }

    @Override public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults){
        if(requestCode==REQ){
            if(grantResults.length==0 || grantResults[0]!=PackageManager.PERMISSION_GRANTED){
                Toast.makeText(this,"Permiso de cámara requerido para usar el flash", Toast.LENGTH_SHORT).show();
            }
        } else super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
}